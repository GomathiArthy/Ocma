export const CourierActionTypes = {
   
    ADD_COURIER : "ADD_COURIER",
    GET_COURIER : "GET_COURIER",
    GET_ALL_COURIER : "GET_ALL_COURIER",
    
}