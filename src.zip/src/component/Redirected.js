const Redirected = () =>{
    return (
        <div>
            404 Not found
        </div>
    )
}

export default Redirected;