import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const NotFound = () => (
    <div>
            <h1>
                Page Not Found!
            </h1>
    </div>
);

export default NotFound;